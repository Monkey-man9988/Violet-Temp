﻿namespace VioletTemp.Initialization
{
    public class PluginInfo
    {
        public const string menuGUID = "com.Violet.VioletTemp.org";
        public const string menuName = "Violet Temp";
        public const string menuVersion = "1.0";
    }
}
