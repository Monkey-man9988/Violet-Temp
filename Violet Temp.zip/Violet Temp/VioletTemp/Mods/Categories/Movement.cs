﻿using System;
using System.Collections.Generic;
using System.Text;
using static VioletTemp.Utilities.GunTemplate;
using static VioletTemp.Menu.Main;
using static VioletTemp.Utilities.Variables;
using static VioletTemp.Utilities.ColorLib;
using static VioletTemp.Utilities.RigManager;
using static VioletTemp.Menu.ButtonHandler;
using static VioletTemp.Mods.ModButtons;
using static VioletTemp.Mods.Categories.Settings;
using UnityEngine;
using Valve.VR;
using System.Reflection;
using BepInEx;
using Photon.Voice;
using VioletTemp.Utilities;
using VioletTemp.Utilities;

namespace VioletTemp.Mods.Categories
{
    public class Move
    {

    }
}
