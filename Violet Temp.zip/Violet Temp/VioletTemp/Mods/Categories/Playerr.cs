﻿using System;
using System.Collections.Generic;
using System.Text;
using static VioletTemp.Utilities.GunTemplate;
using static VioletTemp.Utilities.ColorLib;
using static VioletTemp.Utilities.Variables;
using static VioletTemp.Menu.Main;
using static VioletTemp.Mods.Categories.Settings;
using UnityEngine;
using UnityEngine.InputSystem;
using VioletTemp.Utilities;
using UnityEngine.XR;
using UnityEngine.Animations.Rigging;
using UnityEngine.XR.Interaction.Toolkit;
using GorillaNetworking;
using VioletTemp.Utilities.Patches;
using VioletTemp.Menu;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using HarmonyLib;
using BepInEx;
using VioletTemp.Utilities;

namespace VioletTemp.Mods.Categories
{
    public class Playerr
    {
       
    }
}
